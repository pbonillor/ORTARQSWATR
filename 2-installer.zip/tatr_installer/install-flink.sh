install_dir=$1

wget --no-check-certificate https://dlcdn.apache.org/flink/flink-1.13.3/flink-1.13.3-bin-scala_2.12.tgz

tar zxvf flink-1.13.3-bin-scala_2.12.tgz

mv flink-1.13.3 $install_dir/flink

rm flink-1.13.3-bin-scala_2.12.tgz

