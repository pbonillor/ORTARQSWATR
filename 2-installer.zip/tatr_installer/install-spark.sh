install_dir=$1
echo "Installing Spark"

wget https://archive.apache.org/dist/spark/spark-2.4.6/spark-2.4.6-bin-hadoop2.7.tgz
tar zxvf spark-2.4.6-bin-hadoop2.7.tgz

mv spark-2.4.6-bin-hadoop2.7 $install_dir/spark
rm spark-2.4.6-bin-hadoop2.7.tgz

wget https://repo1.maven.org/maven2/org/apache/spark/spark-sql-kafka-0-10_2.11/2.4.6/spark-sql-kafka-0-10_2.11-2.4.6.jar

mv spark-sql-kafka-0-10_2.11-2.4.6.jar $install_dir/spark/jars/

wget https://repo1.maven.org/maven2/org/apache/kafka/kafka-clients/2.8.1/kafka-clients-2.8.1.jar

mv kafka-clients-2.8.1.jar $install_dir/spark/jars/

