echo "Installing systemd services"

sudo cp services/* /etc/systemd/system/
sudo systemctl daemon-reload

sudo systemctl enable flink
sudo systemctl enable jupyter
sudo systemctl enable kafka
sudo systemctl enable kafka-zookeeper
sudo systemctl enable nifi

