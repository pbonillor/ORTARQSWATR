install_dir=$1
echo "Install Conda and Jupyter Notebook"

wget https://repo.anaconda.com/miniconda/Miniconda3-py37_4.8.3-Linux-x86_64.sh
bash Miniconda3-py37_4.8.3-Linux-x86_64.sh -b -p $install_dir/conda

sudo ln -s $install_dir/conda/etc/profile.d/conda.sh /etc/profile.d/

source $install_dir/conda/etc/profile.d/conda.sh

conda install -y -c conda-forge notebook
conda install -y -c conda-forge nb_conda_kernels
conda install -y pip

mkdir $install_dir/notebooks

rm Miniconda3-py37_4.8.3-Linux-x86_64.sh
