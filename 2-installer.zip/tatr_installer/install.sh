
install_dir=/home/azureuser

./install-mosquitto.sh
./install-jupyter.sh $install_dir
./install-packages.sh $install_dir
./install-java.sh
./install-spark.sh $install_dir
./install-nifi.sh $install_dir
./install-kafka.sh $install_dir
./install-flink.sh $install_dir
./install-services.sh

