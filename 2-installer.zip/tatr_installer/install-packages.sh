install_dir=$1

echo "Install paho por mqtt"
$install_dir/conda/bin/pip install paho-mqtt

echo "Install findspark"
$install_dir/conda/bin/pip install findspark

