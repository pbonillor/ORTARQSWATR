install_dir=$1
echo "Install NiFi"

wget --no-check-certificate https://dlcdn.apache.org/nifi/1.14.0/nifi-1.14.0-bin.zip
unzip nifi-1.14.0-bin.zip
mv nifi-1.14.0 $install_dir/nifi
rm nifi-1.14.0-bin.zip

$install_dir/nifi/bin/nifi.sh set-single-user-credentials admin practiconifi

