install_dir=$1
echo "Install Kafka"

wget https://archive.apache.org/dist/kafka/2.8.1/kafka_2.13-2.8.1.tgz

tar zxvf kafka_2.13-2.8.1.tgz

mv kafka_2.13-2.8.1 $install_dir/kafka

rm kafka_2.13-2.8.1.tgz
