echo "Install mosquitto"

sudo yum -y install epel-release
sudo yum -y install mosquitto
sudo systemctl enable mosquitto

